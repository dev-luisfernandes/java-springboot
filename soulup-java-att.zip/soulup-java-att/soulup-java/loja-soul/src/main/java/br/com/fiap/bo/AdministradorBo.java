package br.com.fiap.bo;

import br.com.fiap.dao.AdministradorDao;
import br.com.fiap.dao.UsuarioDao;
import br.com.fiap.entities.Administrador;
import br.com.fiap.entities.Usuario;
import br.com.fiap.excecoes.ExcecoesRegraNegocio;

import java.sql.SQLException;
import java.util.List;

public class AdministradorBo {

    private AdministradorDao administradorDao = new AdministradorDao();

    public List<Usuario> listarTodosUsuarios(String adminEmail, String adminSenha)
            throws SQLException, ClassNotFoundException, ExcecoesRegraNegocio {

        // Valida as credenciais do Administrador no banco Oracle
        Administrador admin = administradorDao.autenticar(adminEmail, adminSenha);
        if (admin == null) {
            throw new ExcecoesRegraNegocio("Acesso negado: Credenciais do Administrador inválidas.");
        }

        // Instancia o UsuarioDao para realizar a consulta
        UsuarioDao usuarioDao = new UsuarioDao();
        return usuarioDao.selecionar();
    }
}