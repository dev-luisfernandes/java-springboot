package br.com.fiap.entities;

public class Usuario {
    private String cpf;
    private String nome;
    private double pontos;
    private int cep;
    private String celular;
    private String email;
    private String dataNascimento;
    private String situacao;
    private String tier;

    public Usuario() {
        this.pontos = 50.0;
        this.situacao = "ATIVO";
        this.tier = "Verde";
    }

    public Usuario(String cpf, String nome, double pontos, int cep, String celular, String email, String dataNascimento, String situacao, String tier) {
        this.cpf = cpf;
        this.nome = nome;
        this.pontos = pontos;
        this.cep = cep;
        this.celular = celular;
        this.email = email;
        this.dataNascimento = dataNascimento;
        this.situacao = situacao;
        this.tier = tier;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPontos() {
        return pontos;
    }

    public void setPontos(double pontos) {
        this.pontos = pontos;
    }

    public int getCep() {
        return cep;
    }

    public void setCep(int cep) {
        this.cep = cep;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "cpf='" + cpf + '\'' +
                ", nome='" + nome + '\'' +
                ", pontos=" + pontos +
                ", cep=" + cep +
                ", celular='" + celular + '\'' +
                ", email='" + email + '\'' +
                ", dataNascimento='" + dataNascimento + '\'' +
                ", situacao='" + situacao + '\'' +
                ", tier='" + tier + '\'' +
                '}';
    }
}