package br.com.fiap.controller;

import br.com.fiap.bo.AdministradorBo;
import br.com.fiap.entities.Usuario;
import br.com.fiap.excecoes.ExcecoesRegraNegocio;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@RestController
@RequestMapping("/administrador")
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
public class AdministradorController {

    private AdministradorBo administradorBo = new AdministradorBo();

    @GetMapping("/usuarios")
    public ResponseEntity<?> listarTodosUsuarios(
            @RequestHeader("Administrador-Email") String adminEmail,
            @RequestHeader("Administrador-Senha") String adminSenha) {
        try {
            List<Usuario> lista = administradorBo.listarTodosUsuarios(adminEmail, adminSenha);
            return ResponseEntity.ok(lista);
        } catch (ExcecoesRegraNegocio e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        } catch (SQLException | ClassNotFoundException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }
}