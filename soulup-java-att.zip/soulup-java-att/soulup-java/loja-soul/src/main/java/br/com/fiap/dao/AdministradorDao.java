package br.com.fiap.dao;

import br.com.fiap.conexoes.ConexaoFactory;
import br.com.fiap.entities.Administrador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdministradorDao {

    public Administrador autenticar(String email, String senha) throws SQLException, ClassNotFoundException {
        Connection conn = new ConexaoFactory().conexao();
        String sql = "SELECT ID_ADMINISTRADOR, NOME, EMAIL, SENHA FROM TB_SOUL_ADMINISTRADOR WHERE EMAIL = ? AND SENHA = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, email);
        stmt.setString(2, senha);

        ResultSet rs = stmt.executeQuery();
        Administrador administrador = null;

        if (rs.next()) {
            administrador = new Administrador(
                    rs.getInt("ID_ADMINISTRADOR"),
                    rs.getString("NOME"),
                    rs.getString("EMAIL"),
                    rs.getString("SENHA")
            );
        }

        rs.close();
        stmt.close();
        conn.close();
        return administrador;
    }
}