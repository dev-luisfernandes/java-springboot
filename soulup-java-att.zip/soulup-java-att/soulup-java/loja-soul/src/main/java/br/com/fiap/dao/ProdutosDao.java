package br.com.fiap.dao;

import br.com.fiap.conexoes.ConexaoFactory;
import br.com.fiap.entities.Produtos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProdutosDao {

    public Connection minhaConexao;

    public ProdutosDao() throws SQLException, ClassNotFoundException {
        this.minhaConexao = new ConexaoFactory().conexao();
    }

    public void inserir(Produtos produto) throws SQLException {
        String sql = "INSERT INTO TB_SOUL_PRODUTOS (NOME, DESCRICAO, IMAGEM_URL, QUANTIDADE, TIPO, PONTOS) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);

        stmt.setString(1, produto.getNome());
        stmt.setString(2, produto.getDescricao());
        stmt.setString(3, produto.getImagemUrl());
        stmt.setInt(4, produto.getQuantidade());
        stmt.setString(5, produto.getTipo());
        stmt.setDouble(6, produto.getPontos());

        stmt.execute();
        stmt.close();
    }

    public ArrayList<Produtos> selecionar() throws SQLException {
        ArrayList<Produtos> lista = new ArrayList<>();
        String sql = "SELECT ID, NOME, DESCRICAO, IMAGEM_URL, QUANTIDADE, TIPO, PONTOS FROM TB_SOUL_PRODUTOS";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Produtos p = new Produtos(
                    rs.getInt("ID"),
                    rs.getString("NOME"),
                    rs.getString("DESCRICAO"),
                    rs.getString("IMAGEM_URL"),
                    rs.getInt("QUANTIDADE"),
                    rs.getString("TIPO"),
                    rs.getDouble("PONTOS")
            );
            lista.add(p);
        }
        rs.close();
        stmt.close();
        return lista;
    }

    public Produtos buscarPorId(int id) throws SQLException {
        Produtos produto = null;
        String sql = "SELECT ID, NOME, DESCRICAO, IMAGEM_URL, QUANTIDADE, TIPO, PONTOS FROM TB_SOUL_PRODUTOS WHERE ID = ?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            produto = new Produtos(
                    rs.getInt("ID"),
                    rs.getString("NOME"),
                    rs.getString("DESCRICAO"),
                    rs.getString("IMAGEM_URL"),
                    rs.getInt("QUANTIDADE"),
                    rs.getString("TIPO"),
                    rs.getDouble("PONTOS")
            );
        }
        rs.close();
        stmt.close();
        return produto;
    }

    public void deletar(int id) throws SQLException {
        String sql = "DELETE FROM TB_SOUL_PRODUTOS WHERE ID = ?";
        PreparedStatement stmt = minhaConexao.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.execute();
        stmt.close();
    }

    public void diminuirEstoque(int id) throws SQLException {
        Produtos produto = buscarPorId(id);
        if (produto != null && produto.getQuantidade() > 0) {
            int novaQuantidade = produto.getQuantidade() - 1;
            PreparedStatement stmt = minhaConexao.prepareStatement("UPDATE TB_SOUL_PRODUTOS SET QUANTIDADE = ? WHERE ID = ?");
            stmt.setInt(1, novaQuantidade);
            stmt.setInt(2, id);
            stmt.executeUpdate();
            stmt.close();
        }
    }
}